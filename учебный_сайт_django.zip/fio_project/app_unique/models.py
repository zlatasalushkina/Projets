from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator


class Genre(models.Model):
    name = models.CharField('Жанр', max_length=100)

    class Meta:
        verbose_name = 'Жанр'
        verbose_name_plural = 'Жанры'
        ordering = ['name']

    def __str__(self):
        return self.name


class Book(models.Model):
    title = models.CharField('Название', max_length=300)
    author = models.CharField('Автор', max_length=200)
    genre = models.ForeignKey(
        Genre, on_delete=models.SET_NULL, null=True, blank=True,
        verbose_name='Жанр', related_name='books'
    )
    year = models.IntegerField('Год издания')
    rating = models.DecimalField(
        'Рейтинг (1–10)',
        max_digits=3,
        decimal_places=1,
        validators=[MinValueValidator(1.0), MaxValueValidator(10.0)]
    )
    description = models.TextField('Описание')
    pages = models.IntegerField('Кол-во страниц', default=0)
    created_at = models.DateTimeField('Добавлено', auto_now_add=True)

    class Meta:
        verbose_name = 'Книга'
        verbose_name_plural = 'Книги'
        ordering = ['title']

    def __str__(self):
        return f'{self.title} — {self.author}'
