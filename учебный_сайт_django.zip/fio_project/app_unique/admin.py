from django.contrib import admin
from .models import Genre, Book


@admin.register(Genre)
class GenreAdmin(admin.ModelAdmin):
    list_display = ['name']
    search_fields = ['name']


@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ['title', 'author', 'genre', 'year', 'rating', 'pages']
    list_filter = ['genre', 'year']
    search_fields = ['title', 'author', 'description']
    list_editable = ['rating']
    list_select_related = ['genre']
    readonly_fields = ['created_at']
