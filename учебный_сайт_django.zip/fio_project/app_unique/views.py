from django.shortcuts import render, get_object_or_404
from django.db.models import Avg, Count
from .models import Book, Genre


def index(request):
    total_books = Book.objects.count()
    avg_rating = Book.objects.aggregate(avg=Avg('rating'))['avg']
    top_books = Book.objects.order_by('-rating')[:3]
    genres = Genre.objects.annotate(book_count=Count('books')).order_by('-book_count')[:5]
    return render(request, 'app_unique/index.html', {
        'total_books': total_books,
        'avg_rating': avg_rating,
        'top_books': top_books,
        'genres': genres,
    })


def books(request):
    genre_id = request.GET.get('genre', '')
    year_from = request.GET.get('year_from', '')
    year_to = request.GET.get('year_to', '')
    sort = request.GET.get('sort', 'title')
    allowed = ['title', '-title', 'author', '-author', 'year', '-year', 'rating', '-rating']
    if sort not in allowed:
        sort = 'title'
    books_qs = Book.objects.select_related('genre').order_by(sort)
    if genre_id:
        try:
            books_qs = books_qs.filter(genre_id=int(genre_id))
        except ValueError:
            pass
    if year_from:
        try:
            books_qs = books_qs.filter(year__gte=int(year_from))
        except ValueError:
            pass
    if year_to:
        try:
            books_qs = books_qs.filter(year__lte=int(year_to))
        except ValueError:
            pass
    genres = Genre.objects.all()
    return render(request, 'app_unique/books.html', {
        'books': books_qs,
        'genres': genres,
        'genre_id': genre_id,
        'year_from': year_from,
        'year_to': year_to,
        'sort': sort,
    })


def book_detail(request, pk):
    book = get_object_or_404(Book, pk=pk)
    return render(request, 'app_unique/book_detail.html', {'book': book})
