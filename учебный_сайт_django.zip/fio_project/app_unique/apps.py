from django.apps import AppConfig


class AppUniqueConfig(AppConfig):
    name = "app_unique"
