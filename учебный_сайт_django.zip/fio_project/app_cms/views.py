from django.shortcuts import render, get_object_or_404
from .models import Page, Article, Category


def index(request):
    pages = Page.objects.filter(is_published=True)
    recent_articles = Article.objects.filter(is_published=True)[:5]
    return render(request, 'app_cms/index.html', {
        'pages': pages,
        'recent_articles': recent_articles,
    })


def page_detail(request, slug):
    page = get_object_or_404(Page, slug=slug, is_published=True)
    return render(request, 'app_cms/page_detail.html', {'page': page})


def articles(request):
    category_slug = request.GET.get('category', '')
    sort = request.GET.get('sort', '-created_at')
    allowed = ['-created_at', 'created_at', 'title', '-title']
    if sort not in allowed:
        sort = '-created_at'
    articles_qs = Article.objects.filter(is_published=True).select_related('category').order_by(sort)
    if category_slug:
        articles_qs = articles_qs.filter(category__slug=category_slug)
    categories = Category.objects.all()
    return render(request, 'app_cms/articles.html', {
        'articles': articles_qs,
        'categories': categories,
        'category_slug': category_slug,
        'sort': sort,
    })


def article_detail(request, slug):
    article = get_object_or_404(Article, slug=slug, is_published=True)
    return render(request, 'app_cms/article_detail.html', {'article': article})
