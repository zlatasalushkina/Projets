from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.shortcuts import redirect

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', lambda request: redirect('about:index'), name='home'),
    path('about/', include('app_about.urls', namespace='about')),
    path('cms/', include('app_cms.urls', namespace='cms')),
    path('unique/', include('app_unique.urls', namespace='unique')),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
