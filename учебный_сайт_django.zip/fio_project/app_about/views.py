from django.shortcuts import render, redirect
from django.db.models import Avg, Min, Max, Count
from .models import AboutMe, Teacher, Classmate, ProgramReview
from .forms import ProgramReviewForm


def index(request):
    about = AboutMe.objects.first()
    reviews_count = ProgramReview.objects.count()
    avg_rating = ProgramReview.objects.aggregate(avg=Avg('rating'))['avg']
    return render(request, 'app_about/index.html', {
        'about': about,
        'reviews_count': reviews_count,
        'avg_rating': avg_rating,
    })


def about_me(request):
    about = AboutMe.objects.first()
    return render(request, 'app_about/about_me.html', {'about': about})


def management(request):
    sort = request.GET.get('sort', 'name')
    allowed = ['name', '-name', 'subject', '-subject', 'position', '-position']
    if sort not in allowed:
        sort = 'name'
    teachers = Teacher.objects.order_by(sort)
    return render(request, 'app_about/management.html', {'teachers': teachers, 'sort': sort})


def classmates(request):
    hobby_filter = request.GET.get('hobby', '')
    sort = request.GET.get('sort', 'name')
    allowed = ['name', '-name', 'hobby', '-hobby']
    if sort not in allowed:
        sort = 'name'
    classmates_qs = Classmate.objects.order_by(sort)
    if hobby_filter:
        classmates_qs = classmates_qs.filter(hobby__icontains=hobby_filter)
    hobbies = Classmate.objects.values_list('hobby', flat=True).distinct().order_by('hobby')
    return render(request, 'app_about/classmates.html', {
        'classmates': classmates_qs,
        'hobbies': hobbies,
        'hobby_filter': hobby_filter,
        'sort': sort,
    })


def reviews(request):
    min_rating = request.GET.get('min_rating', '')
    max_rating = request.GET.get('max_rating', '')
    sort = request.GET.get('sort', '-created_at')
    allowed = ['-created_at', 'created_at', '-rating', 'rating', 'nickname']
    if sort not in allowed:
        sort = '-created_at'
    reviews_qs = ProgramReview.objects.order_by(sort)
    if min_rating:
        try:
            reviews_qs = reviews_qs.filter(rating__gte=float(min_rating))
        except ValueError:
            pass
    if max_rating:
        try:
            reviews_qs = reviews_qs.filter(rating__lte=float(max_rating))
        except ValueError:
            pass
    return render(request, 'app_about/reviews.html', {
        'reviews': reviews_qs,
        'sort': sort,
        'min_rating': min_rating,
        'max_rating': max_rating,
    })


def add_review(request):
    if request.method == 'POST':
        form = ProgramReviewForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('about:reviews')
    else:
        form = ProgramReviewForm()
    return render(request, 'app_about/add_review.html', {'form': form})


def statistics(request):
    stats = ProgramReview.objects.aggregate(
        total=Count('id'),
        avg_rating=Avg('rating'),
        min_rating=Min('rating'),
        max_rating=Max('rating'),
    )
    rating_groups = [
        {'label': 'Отлично (8–10)', 'count': ProgramReview.objects.filter(rating__gte=8).count()},
        {'label': 'Хорошо (6–7.9)', 'count': ProgramReview.objects.filter(rating__gte=6, rating__lt=8).count()},
        {'label': 'Удовлетворительно (4–5.9)', 'count': ProgramReview.objects.filter(rating__gte=4, rating__lt=6).count()},
        {'label': 'Плохо (0–3.9)', 'count': ProgramReview.objects.filter(rating__lt=4).count()},
    ]
    return render(request, 'app_about/statistics.html', {
        'stats': stats,
        'rating_groups': rating_groups,
    })
