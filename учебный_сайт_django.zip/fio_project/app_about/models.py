from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator


class AboutMe(models.Model):
    name = models.CharField('ФИО', max_length=200)
    group = models.CharField('Группа', max_length=50)
    year_of_enrollment = models.IntegerField('Год поступления')
    program = models.CharField('Образовательная программа', max_length=300)
    bio = models.TextField('О себе')
    photo = models.ImageField('Фото', upload_to='about/', blank=True, null=True)

    class Meta:
        verbose_name = 'Информация обо мне'
        verbose_name_plural = 'Информация обо мне'

    def __str__(self):
        return self.name


class Teacher(models.Model):
    name = models.CharField('ФИО', max_length=200)
    position = models.CharField('Должность', max_length=200)
    subject = models.CharField('Дисциплина', max_length=200)
    photo = models.ImageField('Фото', upload_to='teachers/', blank=True, null=True)
    bio = models.TextField('Описание', blank=True)

    class Meta:
        verbose_name = 'Преподаватель'
        verbose_name_plural = 'Преподаватели'
        ordering = ['name']

    def __str__(self):
        return self.name


class Classmate(models.Model):
    name = models.CharField('ФИО', max_length=200)
    hobby = models.CharField('Увлечение', max_length=200)
    photo = models.ImageField('Фото', upload_to='classmates/', blank=True, null=True)
    notes = models.TextField('Заметки', blank=True)

    class Meta:
        verbose_name = 'Однокурсник'
        verbose_name_plural = 'Однокурсники'
        ordering = ['name']

    def __str__(self):
        return self.name


class ProgramReview(models.Model):
    nickname = models.CharField('Ник комментатора', max_length=100)
    content = models.TextField('Содержание отзыва')
    rating = models.DecimalField(
        'Оценка (0–10)',
        max_digits=3,
        decimal_places=1,
        validators=[MinValueValidator(0.0), MaxValueValidator(10.0)]
    )
    created_at = models.DateTimeField('Дата отправки', auto_now_add=True)

    class Meta:
        verbose_name = 'Отзыв о программе'
        verbose_name_plural = 'Отзывы о программе'
        ordering = ['-created_at']

    def __str__(self):
        return f'{self.nickname} — {self.rating}'
