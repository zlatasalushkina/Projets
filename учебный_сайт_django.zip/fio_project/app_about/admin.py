from django.contrib import admin
from .models import AboutMe, Teacher, Classmate, ProgramReview


@admin.register(AboutMe)
class AboutMeAdmin(admin.ModelAdmin):
    list_display = ['name', 'group', 'year_of_enrollment', 'program']


@admin.register(Teacher)
class TeacherAdmin(admin.ModelAdmin):
    list_display = ['name', 'position', 'subject']
    search_fields = ['name', 'subject', 'position']
    list_filter = ['position']


@admin.register(Classmate)
class ClassmateAdmin(admin.ModelAdmin):
    list_display = ['name', 'hobby']
    search_fields = ['name', 'hobby']
    list_filter = ['hobby']


@admin.register(ProgramReview)
class ProgramReviewAdmin(admin.ModelAdmin):
    list_display = ['nickname', 'rating', 'created_at']
    list_filter = ['rating']
    search_fields = ['nickname', 'content']
    readonly_fields = ['created_at']
