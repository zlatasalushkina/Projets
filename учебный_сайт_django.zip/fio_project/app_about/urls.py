from django.urls import path
from . import views

app_name = 'about'

urlpatterns = [
    path('', views.index, name='index'),
    path('me/', views.about_me, name='about_me'),
    path('management/', views.management, name='management'),
    path('classmates/', views.classmates, name='classmates'),
    path('reviews/', views.reviews, name='reviews'),
    path('reviews/add/', views.add_review, name='add_review'),
    path('statistics/', views.statistics, name='statistics'),
]
