from django import forms
from .models import ProgramReview


class ProgramReviewForm(forms.ModelForm):
    class Meta:
        model = ProgramReview
        fields = ['nickname', 'content', 'rating']
        widgets = {
            'nickname': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Ваш ник'}),
            'content': forms.Textarea(attrs={'class': 'form-control', 'rows': 4, 'placeholder': 'Ваш отзыв...'}),
            'rating': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.1', 'min': '0', 'max': '10'}),
        }
        labels = {
            'nickname': 'Ник комментатора',
            'content': 'Содержание отзыва',
            'rating': 'Оценка (от 0 до 10)',
        }
